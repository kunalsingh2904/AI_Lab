import sys
import os

file = open(sys.argv[1], "r")
typ = file.read(1)
typ = int(typ[0])

if typ == 0:
    os.system("python3  bfs.py " + sys.argv[1]  )
elif typ == 1:
    os.system("python3  dfs.py " + sys.argv[1]  )
elif typ == 2:
    os.system("python3  dfid.py " + sys.argv[1]  )

    

