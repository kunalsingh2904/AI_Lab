#!/bin/bash
python3 control.py $1