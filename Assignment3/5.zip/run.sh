python3 SimulatedAnnealing.py $1
python3 Genetic.py $1
python3 Ant_Opt.py $1